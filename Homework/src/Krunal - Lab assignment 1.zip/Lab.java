public class Lab {
    public static void main (String[]args) {
        int x = 43560;
        int y = 389767;
        //where the x is oneAcre, y is total value and z is result
        int z = y / x;
        System.out.println(z + " acre ");


    }
}


