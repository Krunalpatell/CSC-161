public class Lab {
    public static void main (String[]args) {
        int x = 43560;
        int y = 389767;
        //where the x is oneAcre and y is total value
        int noOfAcre = y / x;
        System.out.println(noOfAcre + " acre ");


    }
}


